<?php

class PageNotFoundController extends Controller {
    public function index() {
        $this->view("pagenotfound");
    }
}